﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3nd
{
    public partial class Form7 : Form
    {
        DataSet ds = new DataSet();
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string addPO = "INSERT INTO software ([name], [discription], [prise], [id_type]) VALUES ('"
                        + textBox1.Text + "', '"
                        + textBox2.Text + "', '"
                        + textBox3.Text + "', '"
                        + ds.Tables[0].Rows[comboBox4.SelectedIndex][0] + "')";
            MyExecuteNonQuery(addPO);
            this.Hide();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            string get_card = "SELECT * FROM type_software";
            SqlDataAdapter da = new SqlDataAdapter(get_card, Program.f1.ConnStr);
            da.Fill(ds, "[type_software]");
            DataTable dt = ds.Tables[0];

            foreach (DataRow row in dt.Rows) comboBox4.Items.Add(row[1]);

        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(Program.f1.ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
