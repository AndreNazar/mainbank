﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3nd
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();

            string getDelivery = "SELECT " +
                "[delivery].[id_delivery], " +
                "[delivery].[id_contract] as [Номер договора], " +
                "[software].[name] as [ПО], " +
                "[worker].[full_name] as [Сотрудник] " +
                "FROM delivery, software, worker " +
                "WHERE ([software].[id_software] = [delivery].[id_software]) " +
                "AND ([worker].[id_worker] = [delivery].[id_worker]) ";
            SqlDataAdapter da = new SqlDataAdapter(getDelivery, Program.f1.ConnStr);
            da.Fill(ds, "[delivery]");

            string getClient = "SELECT " +
                "[client].[id_client], " +
                "[client].[name] as [Клиент], " +
                "[client].[address] as [Адрес], " +
                "[client].[tel] as [Телефон] " +
                "FROM client ";
            da = new SqlDataAdapter(getClient, Program.f1.ConnStr);
            da.Fill(ds, "[client]");

            string getContract = "SELECT " +
                "[contract].[id_contract] as [Номер договора], " +
                "[client].[name] as [Клиент], " +
                "[contract].[date_of_signing] as [Дата заключения] " +
                "FROM contract, client " +
                "WHERE ([contract].[id_client] = [client].[id_client]) ";
            da = new SqlDataAdapter(getContract, Program.f1.ConnStr);
            da.Fill(ds, "[contract]");




            dataGridView1.DataSource = ds.Tables["[delivery]"].DefaultView;
            dataGridView1.Columns[0].Visible = false;
            dataGridView2.DataSource = ds.Tables["[client]"].DefaultView;
            dataGridView2.Columns[0].Visible = false;
            dataGridView3.DataSource = ds.Tables["[contract]"].DefaultView;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            string DeleteValue = "DELETE FROM delivery WHERE ([delivery].[id_delivery] = '" + Convert.ToString(dataGridView1[0, index].Value) + "')";
            dataGridView1.Rows.RemoveAt(index);
            MyExecuteNonQuery(DeleteValue);
        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(Program.f1.ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            string DeleteValue = "DELETE FROM client WHERE ([client].[id_client] = '" + Convert.ToString(dataGridView1[0, index].Value) + "')";
            dataGridView1.Rows.RemoveAt(index);
            MyExecuteNonQuery(DeleteValue);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(tabControl1.SelectedIndex == 0)
            {
                string getValue = "SELECT " +
                "[delivery].[id_delivery], " +
                "[delivery].[id_contract] as [Номер договора], " +
                "[software].[name] as [ПО], " +
                "[worker].[full_name] as [Сотрудник] " +
                "FROM delivery, software, worker " +
                "WHERE ([software].[id_software] = [delivery].[id_software]) " +
                "AND ([worker].[id_worker] = [delivery].[id_worker]) " +
                "AND (([delivery].[id_contract] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([software].[name] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([worker].[full_name] LIKE '%" + textBox1.Text + "%')) ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                DataSet ds = new DataSet();
                da.Fill(ds, "[delivery]");
                dataGridView1.DataSource = ds.Tables["[delivery]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
            if(tabControl1.SelectedIndex == 1)
            {

                string getValue = "SELECT " +
                "[client].[id_client], " +
                "[client].[name] as [Клиент], " +
                "[client].[address] as [Адрес], " +
                "[client].[tel] as [Телефон] " +
                "FROM client " +
                    "WHERE (([client].[name] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([client].[address] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([client].[tel] LIKE '%" + textBox1.Text + "%')) ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                DataSet ds = new DataSet();
                da.Fill(ds, "[client]");
                dataGridView1.DataSource = ds.Tables["[client]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
            if(tabControl1.SelectedIndex == 2)
            {
                string getValue = "SELECT " +
                "[contract].[id_contract] as [Номер договора], " +
                "[client].[name] as [Клиент], " +
                "[contract].[date_of_signing] as [Дата заключения] " +
                "FROM contract, client " +
                "WHERE ([contract].[id_client] = [client].[id_client]) " +
                "AND (([contract].[id_contract] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([client].[name] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([contract].[date_of_signing] LIKE '%" + textBox1.Text + "%')) ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                DataSet ds = new DataSet();
                da.Fill(ds, "[client]");
                dataGridView1.DataSource = ds.Tables["[client]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Form3_Load(sender, e);
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }
    }
}
