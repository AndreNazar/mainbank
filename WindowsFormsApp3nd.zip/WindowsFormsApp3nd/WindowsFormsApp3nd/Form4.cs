﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3nd
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO worker ([login], [password], [id_role], [full_name], [salary]) VALUES ('"
                        + textBox2.Text + "', '"
                        + textBox3.Text + "', '"
                        + (comboBox1.SelectedIndex + 1) + "', '"
                        + textBox1.Text + "', '"
                        + textBox4.Text + "')";
            MyExecuteNonQuery(sql);
            this.Hide();
        }

        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(Program.f1.ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }
    }
}
