﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3nd
{
    public partial class Form1 : Form
    {
        public string ConnStr = @"Data Source=DESKTOP-VCPHD34;Initial Catalog=pasha;Integrated Security=True";
        //public string ConnStr = @"Data Source=CLASS211-PREPOD;Initial Catalog=pasha;User ID=sa;Password=111";
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {

            string SqlText = "SELECT * FROM worker ";
            SqlDataAdapter da = new SqlDataAdapter(SqlText, ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[workers]");
            DataTable dt = ds.Tables[0];
            foreach (DataRow row in dt.Rows)
            {
                Form2 f2 = new Form2();
                Form3 f3 = new Form3();

                var login = row[1].ToString();
                var password = row[2].ToString();
                var role = row[3].ToString();
                label4.Visible = false;
                if ((login == textBox1.Text) && (password == textBox2.Text))
                {
                    if (role == "1") f2.Show();
                    else f3.Show();
                    return;
                }
                else label4.Visible = true;
            }
        }
    }
}
