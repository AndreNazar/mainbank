﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3nd
{
    public partial class Form6 : Form
    {
        DataSet ds = new DataSet();
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

            string get_contr = "SELECT * FROM contract";
            SqlDataAdapter da = new SqlDataAdapter(get_contr, Program.f1.ConnStr);
            da.Fill(ds, "[contract]");
            DataTable dt1 = ds.Tables[0]; 

            foreach (DataRow row in dt1.Rows) comboBox3.Items.Add(row[0]);



            string get_PO = "SELECT * FROM software";
            da = new SqlDataAdapter(get_PO, Program.f1.ConnStr);
            da.Fill(ds, "[software]");
            DataTable dt2 = ds.Tables[1];

            foreach (DataRow row in dt2.Rows) comboBox2.Items.Add(row[1]);



            string get_worker = "SELECT * FROM worker";
            da = new SqlDataAdapter(get_worker, Program.f1.ConnStr);
            da.Fill(ds, "[worker]");
            DataTable dt3 = ds.Tables[2];

            foreach (DataRow row in dt3.Rows) comboBox1.Items.Add(row[4]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string addDelivery = "INSERT INTO delivery ([id_contract], [id_software], [id_worker]) VALUES ('"
                        + ds.Tables[0].Rows[comboBox3.SelectedIndex][0] + "', '"
                        + ds.Tables[1].Rows[comboBox2.SelectedIndex][0] + "', '"
                        + ds.Tables[2].Rows[comboBox1.SelectedIndex][0] + "')";
            MyExecuteNonQuery(addDelivery);
            this.Hide();

        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(Program.f1.ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }
    }
}
