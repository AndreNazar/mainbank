﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3nd
{
    public partial class Form2 : Form
    {
        int act_table = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            if (comboBox1.SelectedIndex == 0)
            {
                act_table = 0;
                string getValue = "SELECT " +
                    "[worker].[id_worker], " +
                    "[worker].[login] as [Логин], " +
                    "[worker].[password] as [Пароль], " +
                    "[roles].[name] as [Должность], " +
                    "[worker].[full_name] as [ФИО], " +
                    "[worker].[salary] as [Зарплата(руб.)] " +
                    "FROM worker, roles " +
                    "WHERE ([worker].[id_role] = [roles].[id_role]) ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                da.Fill(ds, "[worker]");
                dataGridView1.DataSource = ds.Tables["[worker]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
            else
            if (comboBox1.SelectedIndex == 1)
            {
                act_table = 1;
                string getValue = "SELECT " +
                    "[software].[id_software], " +
                    "[software].[name] as [Название], " +
                    "[software].[discription] as [Описание], " +
                    "[software].[prise] as [Цена], " +
                    "[type_software].[name_type] as [Тип] " +
                    "FROM software, type_software " +
                    "WHERE ([software].[id_type] = [type_software].[id_type]) ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                da.Fill(ds, "[software]");
                dataGridView1.DataSource = ds.Tables["[software]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
            else
            if (comboBox1.SelectedIndex == 2)
            {
                act_table = 2;
                string getValue = "SELECT " +
                    "[type_software].[id_type], " +
                    "[type_software].[name_type] as [Тип ПО] " +
                    "FROM type_software ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                da.Fill(ds, "[type_software]");
                dataGridView1.DataSource = ds.Tables["[type_software]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            Form7 f7 = new Form7();
            Form8 f8 = new Form8();
            if (act_table == 0) f4.Show();
            if (act_table == 1) f7.Show();
            if (act_table == 2) f8.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            int index = dataGridView1.CurrentCell.RowIndex;
            string DeleteValue = "";
            if (act_table == 0)
            {
                DeleteValue = "DELETE FROM worker WHERE ([worker].[id_worker] = '" + Convert.ToString(dataGridView1[0, index].Value) + "')";
            }
            if (act_table == 1)
            {
                DeleteValue = "DELETE FROM software WHERE ([software].[id_software] = '" + Convert.ToString(dataGridView1[0, index].Value) + "')";
            }
            if (act_table == 2)
            {
                DeleteValue = "DELETE FROM type_software WHERE ([type_software].[id_type] = '" + Convert.ToString(dataGridView1[0, index].Value) + "')";
            }

            dataGridView1.Rows.RemoveAt(index);

            MyExecuteNonQuery(DeleteValue);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (act_table == 0)
            {
                string getValue = "SELECT " +
                    "[worker].[id_worker], " +
                    "[worker].[login] as [Логин], " +
                    "[worker].[password] as [Пароль], " +
                    "[roles].[name] as [Должность], " +
                    "[worker].[full_name] as [ФИО], " +
                    "[worker].[salary] as [Зарплата(руб.)] " +
                    "FROM worker, roles " +
                    "WHERE ([worker].[id_role] = [roles].[id_role]) " +
                    "AND (([worker].[login] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([worker].[password] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([roles].[name] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([worker].[full_name] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([worker].[salary] LIKE '%" + textBox1.Text + "%')) ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                DataSet ds = new DataSet();
                da.Fill(ds, "[worker]");
                dataGridView1.DataSource = ds.Tables["[worker]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
            if (act_table == 1)
            {
                string getValue = "SELECT " +
                    "[software].[id_software], " +
                    "[software].[name] as [Название], " +
                    "[software].[discription] as [Описание], " +
                    "[software].[prise] as [Цена], " +
                    "[type_software].[name_type] as [Тип] " +
                    "FROM software, type_software " +
                    "WHERE ([software].[id_type] = [type_software].[id_type]) " +
                "AND (([software].[name] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([software].[discription] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([software].[prise] LIKE '%" + textBox1.Text + "%') " +
                    "OR ([type_software].[name_type] LIKE '%" + textBox1.Text + "%')) ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                DataSet ds = new DataSet();
                da.Fill(ds, "[software]");
                dataGridView1.DataSource = ds.Tables["[software]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
            if (act_table == 2)
            {
                string getValue = "SELECT " +
                    "[type_software].[id_type], " +
                    "[type_software].[name_type] as [Тип ПО] " +
                    "FROM type_software " +
                    "WHERE ([type_software].[name_type] LIKE '%" + textBox1.Text + "%') ";
                SqlDataAdapter da = new SqlDataAdapter(getValue, Program.f1.ConnStr);
                DataSet ds = new DataSet();
                da.Fill(ds, "[type_software]");
                dataGridView1.DataSource = ds.Tables["[type_software]"].DefaultView;
                dataGridView1.Columns[0].Visible = false;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(Program.f1.ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }
    }
}
