﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3nd
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string addClient = "INSERT INTO client ([name], [address], [tel]) VALUES ('"
                        + textBox1.Text + "', '"
                        + textBox2.Text + "', '"
                        + textBox3.Text + "')";
            MyExecuteNonQuery(addClient);

            string last_client = "SELECT * FROM client ORDER BY id_client DESC";
            SqlDataAdapter da = new SqlDataAdapter(last_client, Program.f1.ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[clients]");

            string addContract = "INSERT INTO contract ([id_client], [date_of_signing]) VALUES ('"
                        + ds.Tables[0].Rows[0][0] + "', '"
                        + DateTime.Now + "')";
            MyExecuteNonQuery(addContract);
            this.Hide();
        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(Program.f1.ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
